from django.urls import path
from .views import ChatMessageView, ChatSessionListView, ChatHistoryView

urlpatterns = [
    path('message/', ChatMessageView.as_view(), name='chat_message'),
    path('sessions/', ChatSessionListView.as_view(), name='chat_sessions'),
    path('sessions/<int:session_id>/history/', ChatHistoryView.as_view(), name='chat_history'),
]
